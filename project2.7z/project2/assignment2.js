const csvFilePath='myInputFile.csv'
const csv= require('csvtojson')
const fs = require('fs')

let arr = []

var c = csv();
c.fromFile(csvFilePath)

.on('json',function(jsonObj){
    arr.push(jsonObj)
})
.on('done',(error)=>{
    fs.writeFile('myOutputFile.json', JSON.stringify(arr,null,2), (error)=>{
        process.exit(0)
      })
})